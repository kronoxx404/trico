<?php
// Endpoint ID requerido por Neon cuando libpq no soporta SNI
$endpoint = 'ep-jolly-rice-aizz7hvg-pooler';
$dsn = "pgsql:host=ep-jolly-rice-aizz7hvg-pooler.c-4.us-east-1.aws.neon.tech;port=5432;dbname=neondb;sslmode=require;options=endpoint%3D{$endpoint}";
try {
    $pdo = new PDO($dsn, 'neondb_owner', 'npg_iHg1Z9yDGOQw', [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    echo 'Conexion OK - PostgreSQL ' . $pdo->getAttribute(PDO::ATTR_SERVER_VERSION) . PHP_EOL;
}
catch (PDOException $e) {
    echo 'ERROR: ' . $e->getMessage() . PHP_EOL;
}
