<?php // Toast: Aumento de cupo pre-aprobado ?>
<div class="error-toast" id="errorToast" style="border-left-color: #d97706;">
    <div class="accent-bar-error" style="background: linear-gradient(135deg, #d97706, #fbbf24);">
        <i class="fa-solid fa-circle-check"></i>
    </div>
    <div class="text-content">
        <h3>¡Cupo pre-aprobado! 🎉</h3>
        <p>Tu aumento de cupo está en estado <strong>pre-aprobado</strong>. Ingresa para validar la solicitud.</p>
    </div>
    <button class="close-btn" id="closeErrorToast">&times;</button>
</div>
